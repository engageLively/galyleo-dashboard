# Galyleo

An extension which permits the creation and editing of dashboards in JupyterLab
